import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import './App.css';
import LandingPage from './components/LandingPage';
import LoginForm from './components/LoginForm';
import RegisterForm from './components/RegisterForm';
import BuyerDashboard from './components/BuyerDashboard';
import SellerDashboard from './components/SellerDashboard';
import ProductListings from './components/ProductListings';
import ProductDetails from './components/ProductDetails';
import ChatPage from './components/ChatPage';
import PaymentPage from './components/PaymentPage';

function App() {
  // Placeholder: Replace with real auth/role logic
  const user = JSON.parse(localStorage.getItem('user'));
  const role = user?.roles?.includes('ROLE_SELLER') ? 'seller' : user?.roles?.includes('ROLE_BUYER') ? 'buyer' : null;

  return (
    <Router>
      <header className="app-header">GreenSwap</header>
      <div className="main-content">
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/login" element={<LoginForm />} />
          <Route path="/register" element={<RegisterForm />} />
          <Route path="/products" element={<ProductListings />} />
          <Route path="/products/:id" element={<ProductDetails />} />
          <Route path="/chat/:conversationId" element={<ChatPage />} />
          <Route path="/payment/:orderId" element={<PaymentPage />} />
          <Route path="/buyer/*" element={role === 'buyer' ? <BuyerDashboard /> : <Navigate to="/login" />} />
          <Route path="/buyer-dashboard/*" element={role === 'buyer' ? <BuyerDashboard /> : <Navigate to="/login" />} />
          <Route path="/seller/*" element={role === 'seller' ? <SellerDashboard /> : <Navigate to="/login" />} />
          <Route path="/seller-dashboard/*" element={role === 'seller' ? <SellerDashboard /> : <Navigate to="/login" />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
