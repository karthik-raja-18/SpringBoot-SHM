import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

function ProductListings() {
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    fetch('/api/products')
      .then(res => res.json())
      .then(data => setProducts(data));
    fetch('/api/products')
      .then(res => res.json())
      .then(data => setCategories([...new Set(data.map(p => p.category))]));
  }, []);

  const handleSearch = e => {
    e.preventDefault();
    fetch(`/api/products/search?query=${search}`)
      .then(res => res.json())
      .then(data => setProducts(data));
  };

  const handleCategory = e => {
    setCategory(e.target.value);
    fetch(`/api/products/category/${e.target.value}`)
      .then(res => res.json())
      .then(data => setProducts(data));
  };

  return (
    <div>
      <h2>Product Listings</h2>
      <form onSubmit={handleSearch} style={{ display: 'flex', gap: '1rem', marginBottom: '1rem' }}>
        <input
          type="text"
          placeholder="Search products..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
        <select value={category} onChange={handleCategory}>
          <option value="">All Categories</option>
          {categories.map(cat => (
            <option key={cat} value={cat}>{cat}</option>
          ))}
        </select>
        <button type="submit">Search</button>
      </form>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '2rem' }}>
        {products.map(product => (
          <div className="card" key={product.id} style={{ width: 300 }}>
            <h3>{product.title}</h3>
            <p>{product.description}</p>
            <p><b>Price:</b> ${product.price}</p>
            <p><b>Category:</b> {product.category}</p>
            <Link to={`/products/${product.id}`} className="btn">View Details</Link>
          </div>
        ))}
      </div>
    </div>
  );
}

export default ProductListings; 