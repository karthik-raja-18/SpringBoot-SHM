import React, { useEffect, useState } from 'react';
import { Link, Routes, Route, Navigate } from 'react-router-dom';

function SellerHome() {
  return <div>Welcome to your Seller Dashboard!</div>;
}
function AddProduct() {
  const [form, setForm] = useState({ title: '', description: '', price: '', category: '', condition: '', imageUrl: '' });
  const [message, setMessage] = useState('');
  const user = JSON.parse(localStorage.getItem('user'));
  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });
  const handleSubmit = e => {
    e.preventDefault();
    fetch('/api/products', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${user.token}`
      },
      body: JSON.stringify(form)
    })
      .then(res => res.ok ? setMessage('Product added!') : setMessage('Error adding product.'));
  };
  return (
    <div>
      <h3>Add New Product</h3>
      <form onSubmit={handleSubmit} style={{ maxWidth: 400 }}>
        <input name="title" placeholder="Title" value={form.title} onChange={handleChange} required />
        <textarea name="description" placeholder="Description" value={form.description} onChange={handleChange} required />
        <input name="price" type="number" placeholder="Price" value={form.price} onChange={handleChange} required min="0" step="0.01" />
        <input name="category" placeholder="Category" value={form.category} onChange={handleChange} required />
        <input name="condition" placeholder="Condition" value={form.condition} onChange={handleChange} required />
        <input name="imageUrl" placeholder="Image URL (optional)" value={form.imageUrl} onChange={handleChange} />
        <button className="btn" type="submit">Add Product</button>
      </form>
      {message && <div style={{ marginTop: 12 }}>{message}</div>}
    </div>
  );
}
function ManageListings() {
  const [products, setProducts] = useState([]);
  const [editId, setEditId] = useState(null);
  const [editForm, setEditForm] = useState({ title: '', description: '', price: '', category: '', condition: '', imageUrl: '' });
  const user = JSON.parse(localStorage.getItem('user'));
  useEffect(() => {
    // Only run on mount
    fetch('/api/products/my-products', {
      headers: { 'Authorization': `Bearer ${user.token}` }
    })
      .then(res => res.json())
      .then(data => setProducts(data));
  }, []);
  const handleDelete = id => {
    fetch(`/api/products/${id}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${user.token}` }
    })
      .then(() => setProducts(prev => prev.filter(p => p.id !== id)));
  
  const handleEdit = product => {
    setEditId(product.id);
    setEditForm({ ...product });
  };
  const handleEditChange = e => setEditForm({ ...editForm, [e.target.name]: e.target.value });
  const handleEditSubmit = e => {
    e.preventDefault();
    fetch(`/api/products/${editId}`, {
      method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        'Authorization': `Bearer ${user.token}`
      },
      body: JSON.stringify(editForm)
    })
      .then(res => {
        if (res.ok) {
          setProducts(prev => prev.map(p => p.id === editId ? { ...editForm, id: editId } : p));
        }
      });
    setEditId(null);
  
  return (
    <div>
      <h3>Manage My Listings</h3>
      {products.length === 0 ? <p>No products found.</p> : (
        <ul>
          {products.map(product => (
            <li key={product.id}>
              {editId === product.id ? (
                <form onSubmit={handleEditSubmit} style={{ display: 'inline' }}>
                  <input name="title" value={editForm.title} onChange={handleEditChange} required />
                  <input name="price" type="number" value={editForm.price} onChange={handleEditChange} required min="0" step="0.01" />
                  <button className="btn" type="submit">Save</button>
                  <button className="btn" type="button" onClick={() => setEditId(null)}>Cancel</button>
                </form>
              ) : (
                <>
                  <b>{product.title}</b> (${product.price})
                  <button className="btn" style={{ marginLeft: 8 }} onClick={() => handleEdit(product)}>Edit</button>
                  <button className="btn" style={{ marginLeft: 8 }} onClick={() => handleDelete(product.id)}>Delete</button>
                </>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
function SellerOrders() {
  const [orders, setOrders] = useState([]);
  const user = JSON.parse(localStorage.getItem('user'));
  useEffect(() => {
    fetch('/api/orders/seller', {
      headers: { 'Authorization': `Bearer ${user.token}` }
    })
      .then(res => res.json())
      .then(data => setOrders(data));
  }, []);
  return (
    <div>
      <h3>Orders Received</h3>
      {orders.length === 0 ? <p>No orders received yet.</p> : (
        <ul>
          {orders.map(order => (
            <li key={order.id}>
              Order #{order.id} - Status: {order.status} - Buyer: {order.buyer?.name}
              <br />
              Placed on: {new Date(order.createdAt).toLocaleString()}
            </li>
          ))}
        </ul>
      )}
            </div>
  );
}
function SellerChat() {
  const [conversations, setConversations] = useState([]);
  const user = JSON.parse(localStorage.getItem('user'));
  useEffect(() => {
    fetch('/api/messages/conversations', {
      headers: { 'Authorization': `Bearer ${user.token}` }
    })
      .then(res => res.json())
      .then(data => setConversations(data));
  }, []);
  return (
    <div>
      <h3>Chat with Buyers</h3>
      {conversations.length === 0 ? <p>No conversations yet.</p> : (
        <ul>
          {conversations.map(conv => (
            <li key={conv.id}>
              <Link to={`/chat/${conv.id}`}>
                Chat with {conv.buyer?.name || conv.seller?.name} about {conv.product?.title}
              </Link>
            </li>
          ))}
        </ul>
          )}
        </div>
  );
}

function SellerDashboard() {
  return (
    <div className="dashboard-theme" style={{ display: 'flex', minHeight: '70vh', background: '#111', color: '#fff' }}>
      <nav style={{ minWidth: 200, marginRight: 32, background: '#222', padding: 16, borderRadius: 8 }}>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          <li><Link style={{ color: '#0f0', fontWeight: 'bold' }} to="home">Dashboard Home</Link></li>
          <li><Link style={{ color: '#0f0' }} to="add">Add New Product</Link></li>
          <li><Link style={{ color: '#0f0' }} to="listings">Manage Listings</Link></li>
          <li><Link style={{ color: '#0f0' }} to="orders">Orders Received</Link></li>
          <li><Link style={{ color: '#0f0' }} to="chat">Chat with Buyers</Link></li>
        </ul>
      </nav>
      <div style={{ flex: 1, background: '#111', color: '#fff', padding: 24, borderRadius: 8 }}>
        <Routes>
          <Route path="home" element={<SellerHome />} />
          <Route path="add" element={<AddProduct />} />
          <Route path="listings" element={<ManageListings />} />
          <Route path="orders" element={<SellerOrders />} />
          <Route path="chat" element={<SellerChat />} />
          <Route path="*" element={<Navigate to="home" />} />
        </Routes>
      </div>
    </div>
  );
}

export default SellerDashboard;