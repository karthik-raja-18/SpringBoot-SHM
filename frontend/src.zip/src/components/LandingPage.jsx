import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/LandingPage.css';

const LandingPage = () => {
  return (
    <div className="landing-page">
      <div className="hero-section">
        <div className="hero-content">
          <h1 className="hero-title">Second-Hand Marketplace</h1>
          <p className="hero-subtitle">
            Buy and sell pre-loved items in your community. 
            Find great deals or give your items a new home.
          </p>
          <div className="hero-buttons">
            <Link to="/register" className="btn btn-primary">
              Get Started
            </Link>
            <Link to="/login" className="btn btn-secondary">
              Sign In
            </Link>
          </div>
        </div>
        <div className="hero-image">
          <div className="marketplace-illustration">
            <div className="floating-card card-1">
              <span>📱</span>
              <p>Electronics</p>
            </div>
            <div className="floating-card card-2">
              <span>👕</span>
              <p>Fashion</p>
            </div>
            <div className="floating-card card-3">
              <span>🏠</span>
              <p>Home & Garden</p>
            </div>
            <div className="floating-card card-4">
              <span>🚗</span>
              <p>Vehicles</p>
            </div>
          </div>
        </div>
      </div>

      <div className="features-section">
        <h2>Why Choose Our Marketplace?</h2>
        <div className="features-grid">
          <div className="feature-card">
            <div className="feature-icon">🔒</div>
            <h3>Secure Transactions</h3>
            <p>Safe and secure buying and selling with verified users</p>
          </div>
          <div className="feature-card">
            <div className="feature-icon">💰</div>
            <h3>Great Deals</h3>
            <p>Find amazing deals on quality pre-owned items</p>
          </div>
          <div className="feature-card">
            <div className="feature-icon">🌱</div>
            <h3>Eco-Friendly</h3>
            <p>Reduce waste by giving items a second life</p>
          </div>
          <div className="feature-card">
            <div className="feature-icon">🏘️</div>
            <h3>Local Community</h3>
            <p>Connect with buyers and sellers in your area</p>
          </div>
        </div>
      </div>

      <div className="cta-section">
        <h2>Ready to Start?</h2>
        <p>Join thousands of users buying and selling in our marketplace</p>
        <Link to="/register" className="btn btn-primary btn-large">
          Create Account
        </Link>
      </div>
    </div>
  );
};

export default LandingPage; 