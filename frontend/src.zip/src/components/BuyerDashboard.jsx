import React, { useEffect, useState } from 'react';
import { Link, Routes, Route, Navigate } from 'react-router-dom';

function BuyerHome() {
  return <div>Welcome to your Buyer Dashboard!</div>;
}
function BuyerOrders() {
  const [orders, setOrders] = useState([]);
  const user = JSON.parse(localStorage.getItem('user'));
  useEffect(() => {
    fetch('/api/orders/buyer', {
      headers: { 'Authorization': `Bearer ${user.token}` }
    })
      .then(res => res.json())
      .then(data => setOrders(data));
  }, [user.token]);
  return (
    <div>
      <h3>My Orders</h3>
      {orders.length === 0 ? <p>No orders found.</p> : (
        <ul>
          {orders.map(order => (
            <li key={order.id}>
              Order #{order.id} - Status: {order.status} - Placed on: {new Date(order.createdAt).toLocaleString()}
              <br />
              <Link to={`/payment/${order.id}`}>View/Pay</Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
function BuyerWishlist() {
  const [wishlist, setWishlist] = useState([]);
  const user = JSON.parse(localStorage.getItem('user'));
  useEffect(() => {
    fetch('/api/wishlist', {
      headers: { 'Authorization': `Bearer ${user.token}` }
    })
      .then(res => res.json())
      .then(data => setWishlist(data));
  }, []);
  const handleRemove = (productId) => {
    fetch(`/api/wishlist/remove/${productId}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${user.token}` }
    })
      .then(() => setWishlist(wishlist.filter(w => w.product.id !== productId)));
  };
  return (
    <div>
      <h3>Saved Items / Wishlist</h3>
      {wishlist.length === 0 ? <p>No saved items.</p> : (
        <ul>
          {wishlist.map(w => (
            <li key={w.id}>
              <Link to={`/products/${w.product.id}`}>{w.product.title}</Link>
              <button className="btn" style={{ marginLeft: 16 }} onClick={() => handleRemove(w.product.id)}>Remove</button>
            </li>
          ))}
        </ul>
                )}
              </div>
  );
}
function BuyerMessages() {
  const [conversations, setConversations] = useState([]);
  const user = JSON.parse(localStorage.getItem('user'));
  useEffect(() => {
    fetch('/api/messages/conversations', {
      headers: { 'Authorization': `Bearer ${user.token}` }
    })
      .then(res => res.json())
      .then(data => setConversations(data));
  }, []);
  return (
    <div>
      <h3>Messages / Conversations</h3>
      {conversations.length === 0 ? <p>No conversations yet.</p> : (
        <ul>
          {conversations.map(conv => (
            <li key={conv.id}>
              <Link to={`/chat/${conv.id}`}>
                Chat with {conv.seller?.name || conv.buyer?.name} about {conv.product?.title}
              </Link>
              </li>
            ))}
          </ul>
      )}
    </div>
  );
}
function BuyerHistory() {
  const [orders, setOrders] = useState([]);
  const user = JSON.parse(localStorage.getItem('user'));
  useEffect(() => {
    fetch('/api/orders/buyer', {
      headers: { 'Authorization': `Bearer ${user.token}` }
    })
      .then(res => res.json())
      .then(data => setOrders(data));
  }, [user.token]);
  return (
    <div>
      <h3>Order History</h3>
      {orders.length === 0 ? <p>No order history found.</p> : (
          <ul>
            {orders.map(order => (
              <li key={order.id}>
              Order #{order.id} - Status: {order.status} - Placed on: {new Date(order.createdAt).toLocaleString()}
              </li>
            ))}
          </ul>
      )}
    </div>
  );
}

function BuyerDashboard() {
  return (
    <div className="dashboard-theme" style={{ display: 'flex', minHeight: '70vh', background: '#111', color: '#fff' }}>
      <nav style={{ minWidth: 200, marginRight: 32, background: '#222', padding: 16, borderRadius: 8 }}>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          <li><Link style={{ color: '#0f0', fontWeight: 'bold' }} to="home">Dashboard Home</Link></li>
          <li><Link style={{ color: '#0f0' }} to="orders">My Orders</Link></li>
          <li><Link style={{ color: '#0f0' }} to="wishlist">Saved Items</Link></li>
          <li><Link style={{ color: '#0f0' }} to="messages">Messages</Link></li>
          <li><Link style={{ color: '#0f0' }} to="history">Order History</Link></li>
        </ul>
      </nav>
      <div style={{ flex: 1, background: '#111', color: '#fff', padding: 24, borderRadius: 8 }}>
        <Routes>
          <Route path="home" element={<BuyerHome />} />
          <Route path="orders" element={<BuyerOrders />} />
          <Route path="wishlist" element={<BuyerWishlist />} />
          <Route path="messages" element={<BuyerMessages />} />
          <Route path="history" element={<BuyerHistory />} />
          <Route path="*" element={<Navigate to="home" />} />
        </Routes>
      </div>
    </div>
  );
}

export default BuyerDashboard;