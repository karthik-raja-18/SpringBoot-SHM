import React, { useEffect, useState, useRef } from 'react';
import { useParams } from 'react-router-dom';

function ChatPage() {
  const { conversationId } = useParams();
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const user = JSON.parse(localStorage.getItem('user'));
  const messagesEndRef = useRef(null);

  useEffect(() => {
    fetch(`/api/messages/conversation/${conversationId}`, {
      headers: { 'Authorization': `Bearer ${user.token}` }
    })
      .then(res => res.json())
      .then(data => setMessages(data));
  }, [conversationId, user.token]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = e => {
    e.preventDefault();
    if (!newMessage.trim()) return;
    fetch(`/api/messages/conversation/${conversationId}/send?content=${encodeURIComponent(newMessage)}`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${user.token}` }
    })
      .then(res => res.json())
      .then(msg => {
        setMessages(prev => [...prev, msg]);
        setNewMessage('');
      });
  };

  return (
    <div className="card" style={{ maxWidth: 600, margin: '2rem auto' }}>
      <h2>Chat</h2>
      <div style={{ maxHeight: 350, overflowY: 'auto', marginBottom: '1rem', background: '#181818', padding: '1rem', borderRadius: 8 }}>
        {messages.map(msg => (
          <div key={msg.id} style={{ marginBottom: 12, textAlign: msg.sender.id === user.id ? 'right' : 'left' }}>
            <span style={{ color: msg.sender.id === user.id ? 'var(--primary-green)' : 'var(--white)', fontWeight: 'bold' }}>
              {msg.sender.name}:
            </span>
            <span style={{ marginLeft: 8 }}>{msg.content}</span>
            <div style={{ fontSize: 12, color: '#aaa' }}>{new Date(msg.timestamp).toLocaleString()}</div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>
      <form onSubmit={handleSend} style={{ display: 'flex', gap: '1rem' }}>
        <input
          type="text"
          value={newMessage}
          onChange={e => setNewMessage(e.target.value)}
          placeholder="Type your message..."
          style={{ flex: 1 }}
        />
        <button className="btn" type="submit">Send</button>
      </form>
    </div>
  );
}

export default ChatPage; 