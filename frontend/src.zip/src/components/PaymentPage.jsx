import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';

function PaymentPage() {
  const { orderId } = useParams();
  const [order, setOrder] = useState(null);
  const [payments, setPayments] = useState([]);
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState('CARD');
  const user = JSON.parse(localStorage.getItem('user'));

  useEffect(() => {
    fetch(`/api/orders/${orderId}`, { headers: { 'Authorization': `Bearer ${user.token}` } })
      .then(res => res.json())
      .then(data => {
        setOrder(data);
        setAmount(data?.total || data?.price || '');
      });
    fetch(`/api/payments/order/${orderId}`, { headers: { 'Authorization': `Bearer ${user.token}` } })
      .then(res => res.json())
      .then(data => setPayments(data));
  }, [orderId, user.token]);

  const handlePay = e => {
    e.preventDefault();
    fetch(`/api/payments/create?orderId=${orderId}&amount=${amount}&method=${method}`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${user.token}` }
    })
      .then(res => res.json())
      .then(payment => setPayments(prev => [...prev, payment]));
  };

  return (
    <div className="card" style={{ maxWidth: 600, margin: '2rem auto' }}>
      <h2>Payment</h2>
      {order && (
        <div style={{ marginBottom: '1rem' }}>
          <p><b>Order:</b> {order.id}</p>
          <p><b>Amount:</b> ${order.total || order.price}</p>
        </div>
      )}
      <form onSubmit={handlePay} style={{ display: 'flex', gap: '1rem', marginBottom: '1rem' }}>
        <input
          type="number"
          value={amount}
          onChange={e => setAmount(e.target.value)}
          placeholder="Amount"
          min="0"
          step="0.01"
        />
        <select value={method} onChange={e => setMethod(e.target.value)}>
          <option value="CARD">Card</option>
          <option value="UPI">UPI</option>
          <option value="CASH">Cash</option>
        </select>
        <button className="btn" type="submit">Pay</button>
      </form>
      <h3>Payment History</h3>
      <ul>
        {payments.map(payment => (
          <li key={payment.id}>
            {payment.method} - ${payment.amount} - {payment.status} ({new Date(payment.paymentDate).toLocaleString()})
          </li>
        ))}
      </ul>
    </div>
  );
}

export default PaymentPage; 