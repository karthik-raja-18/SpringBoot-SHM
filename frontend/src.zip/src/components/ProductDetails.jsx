import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';

function ProductDetails() {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem('user'));
  const isBuyer = user?.roles?.includes('ROLE_BUYER');

  useEffect(() => {
    fetch(`/api/products/${id}`)
      .then(res => res.json())
      .then(data => {
        setProduct(data);
        setLoading(false);
      });
  }, [id]);

  if (loading) return <div>Loading...</div>;
  if (!product) return <div>Product not found.</div>;

  const handleContactSeller = () => {
    // Start or get conversation, then navigate to chat
    fetch(`/api/messages/start?buyerId=${user.id}&sellerId=${product.seller.id}&productId=${product.id}`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${user.token}` }
    })
      .then(res => res.json())
      .then(conv => navigate(`/chat/${conv.id}`));
  };

  const handleBuy = () => {
    // Redirect to payment page for this product/order
    navigate(`/payment/${product.id}`);
  };

  return (
    <div className="card" style={{ maxWidth: 600, margin: '2rem auto' }}>
      <h2>{product.title}</h2>
      <p>{product.description}</p>
      <p><b>Price:</b> ${product.price}</p>
      <p><b>Category:</b> {product.category}</p>
      <p><b>Condition:</b> {product.condition}</p>
      <p><b>Seller:</b> {product.seller?.name || 'N/A'}</p>
      {isBuyer && (
        <div style={{ marginTop: '1.5rem', display: 'flex', gap: '1rem' }}>
          <button className="btn" onClick={handleContactSeller}>Contact Seller</button>
          <button className="btn" onClick={handleBuy}>Buy Now</button>
        </div>
      )}
      <div style={{ marginTop: '2rem' }}>
        <Link to="/products">&larr; Back to Listings</Link>
      </div>
    </div>
  );
}

export default ProductDetails; 